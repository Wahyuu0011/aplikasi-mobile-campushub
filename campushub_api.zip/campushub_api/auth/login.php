<?php
error_reporting(0);
ini_set('display_errors', 0);
ob_clean();
header('Content-Type: application/json');

include '../config/db.php';

// CEK DATA ADA ATAU TIDAK
if (!isset($_POST['email']) || !isset($_POST['password'])) {
    echo json_encode([
        "status" => false,
        "message" => "Email dan password wajib diisi"
    ]);
    exit;
}

$email = $_POST['email'];
$password = $_POST['password'];

$q = mysqli_query($conn,
  "SELECT * FROM users WHERE email='$email' AND password='$password'"
);

if (mysqli_num_rows($q) > 0) {
    echo json_encode([
        "status" => true,
        "message" => "Login berhasil"
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Login gagal"
    ]);
}
