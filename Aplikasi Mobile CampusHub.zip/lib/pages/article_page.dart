import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'article_detail_page.dart';
import 'article_add_page.dart';
import 'article_edit_page.dart';

class ArticlePage extends StatefulWidget {
  const ArticlePage({super.key});

  @override
  State<ArticlePage> createState() => _ArticlePageState();
}

class _ArticlePageState extends State<ArticlePage> {
  List articles = [];
  bool loading = true;

  final String apiBase = 'http://10.0.2.2/campushub_api/articles';

  @override
  void initState() {
    super.initState();
    getArticles();
  }

  // ================= GET ARTICLE =================
  Future<void> getArticles() async {
    setState(() => loading = true);

    final response = await http.get(
      Uri.parse('$apiBase/list.php'),
    );

    final data = json.decode(response.body);

    if (data['status'] == true) {
      setState(() {
        articles = data['data'];
        loading = false;
      });
    } else {
      setState(() => loading = false);
    }
  }

  // ================= TAMBAHAN REFRESH =================
  Future<void> _refreshArticles() async {
    await getArticles();
  }

  // ================= DELETE ARTICLE =================
  Future<void> deleteArticle(String id) async {
    await http.post(
      Uri.parse('$apiBase/hapus.php'),
      body: {'id': id},
    );

    getArticles();
  }

  // ================= CONFIRM DELETE =================
  void confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Artikel'),
        content: const Text('Yakin ingin menghapus artikel ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              deleteArticle(id);
            },
            child: const Text(
              'Hapus',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Artikel Mahasiswa'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Tambah Artikel',
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ArticleAddPage(),
                ),
              );

              if (result == true) getArticles();
            },
          ),
        ],
      ),

      body: loading
          ? const Center(child: CircularProgressIndicator())
          : articles.isEmpty
          ? const Center(
        child: Text(
          'Belum ada artikel',
          style: TextStyle(color: Colors.grey),
        ),
      )
          : RefreshIndicator(
        onRefresh: _refreshArticles,
        child: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          itemCount: articles.length,
          itemBuilder: (context, index) {
            final item = articles[index];

            return Container(
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        item['image'],
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      item['title'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      item['content'],
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              ArticleDetailPage(article: item),
                        ),
                      );
                    },
                  ),

                  const Divider(height: 1),

                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton.icon(
                          icon:
                          const Icon(Icons.edit, size: 18),
                          label: const Text('Edit'),
                          onPressed: () async {
                            final result =
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    ArticleEditPage(
                                        article: item),
                              ),
                            );

                            if (result == true) getArticles();
                          },
                        ),
                        TextButton.icon(
                          icon: const Icon(Icons.delete,
                              size: 18, color: Colors.red),
                          label: const Text(
                            'Hapus',
                            style:
                            TextStyle(color: Colors.red),
                          ),
                          onPressed: () =>
                              confirmDelete(
                                  item['id'].toString()),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
