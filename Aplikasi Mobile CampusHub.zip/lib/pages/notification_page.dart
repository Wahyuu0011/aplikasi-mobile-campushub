import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'message_page.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  bool loading = true;
  List notifications = [];

  final String apiBase = 'http://10.0.2.2/campushub_api/messages';

  @override
  void initState() {
    super.initState();
    getNotifications();
  }

  // ================= GET NOTIFICATION =================
  Future<void> getNotifications() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBase/list_all.php'),
      );

      final data = json.decode(response.body);

      if (data['status'] == true) {
        setState(() {
          // hanya pesan dari USER
          notifications = data['data']
              .where((item) => item['sender'] == 'user')
              .toList();
          loading = false;
        });
      } else {
        setState(() => loading = false);
      }
    } catch (e) {
      debugPrint(e.toString());
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifikasi'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : notifications.isEmpty
          ? const Center(
        child: Text(
          'Tidak ada notifikasi',
          style: TextStyle(color: Colors.grey),
        ),
      )
          : ListView.builder(
        itemCount: notifications.length,
        itemBuilder: (context, index) {
          final item = notifications[index];

          return ListTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.blue,
              child: Icon(
                Icons.person,
                color: Colors.white,
              ),
            ),
            title: Text(
              'Pesan baru dari user',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              item['message'] ?? '',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: Text(
              item['created_at'] ?? '',
              style: const TextStyle(
                fontSize: 11,
                color: Colors.grey,
              ),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MessagePage(
                    userId: item['user_id'],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
