import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'article_detail_page.dart';

class BookmarkPage extends StatefulWidget {
  const BookmarkPage({super.key});

  @override
  State<BookmarkPage> createState() => _BookmarkPageState();
}

class _BookmarkPageState extends State<BookmarkPage> {
  List bookmarkedArticles = [];
  bool loading = true;

  Future<void> loadBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarkIds = prefs.getStringList('bookmarks') ?? [];

    if (bookmarkIds.isEmpty) {
      setState(() {
        loading = false;
      });
      return;
    }

    // Ambil semua artikel dari API
    final response = await http.get(
      Uri.parse('http://10.0.2.2/campushub_api/articles/list.php'),
    );

    final data = json.decode(response.body);

    if (data['status'] == true) {
      final allArticles = data['data'];

      // filter artikel yg di-bookmark
      bookmarkedArticles = allArticles.where((article) {
        return bookmarkIds.contains(article['id'].toString());
      }).toList();
    }

    setState(() {
      loading = false;
    });
  }

  // ========== TAMBAHAN REFRESH ==========
  Future<void> _refreshBookmarks() async {
    setState(() {
      loading = true;
    });
    await loadBookmarks();
  }

  @override
  void initState() {
    super.initState();
    loadBookmarks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookmark'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : bookmarkedArticles.isEmpty
          ? RefreshIndicator(
        onRefresh: _refreshBookmarks,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(height: 200),
            Center(
              child: Text(
                'Belum ada artikel yang dibookmark',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: _refreshBookmarks,
        child: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          itemCount: bookmarkedArticles.length,
          itemBuilder: (context, index) {
            final item = bookmarkedArticles[index];

            return Container(
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color:
                    Colors.black.withValues(alpha: 0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    item['image'],
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                  ),
                ),
                title: Text(
                  item['title'],
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          ArticleDetailPage(article: item),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
