import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ArticleAddPage extends StatefulWidget {
  const ArticleAddPage({super.key});

  @override
  State<ArticleAddPage> createState() => _ArticleAddPageState();
}

class _ArticleAddPageState extends State<ArticleAddPage> {
  final titleController = TextEditingController();
  final contentController = TextEditingController();
  final imageController = TextEditingController();

  Future<void> addArticle() async {
    await http.post(
      Uri.parse('http://10.0.2.2/campushub_api/articles/tambah.php'),
      body: {
        'title': titleController.text,
        'content': contentController.text,
        'image': imageController.text,
      },
    );

    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Artikel'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _field(titleController, 'Judul Artikel'),
            const SizedBox(height: 12),
            _field(contentController, 'Isi Artikel', maxLines: 5),
            const SizedBox(height: 12),
            _field(imageController, 'URL Gambar'),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.save),
                label: const Text('Simpan Artikel'),
                onPressed: addArticle,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {int maxLines = 1}) {
    return TextField(
      controller: c,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
