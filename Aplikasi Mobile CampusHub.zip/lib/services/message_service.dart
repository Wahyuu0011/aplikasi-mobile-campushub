import 'dart:convert';
import 'package:http/http.dart' as http;

class MessageService {
  static const String baseUrl =
      'http://10.0.2.2/campushub_api/messages';

  static Future<List> getMessages(int userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/list.php?user_id=$userId'),
    );

    final data = json.decode(response.body);
    return data['data'] ?? [];
  }

  static Future<bool> sendMessage(int userId, String message) async {
    final response = await http.post(
      Uri.parse('$baseUrl/add.php'),
      body: {
        'user_id': userId.toString(),
        'message': message,
      },
    );

    final data = json.decode(response.body);
    return data['status'] == true;
  }
}
