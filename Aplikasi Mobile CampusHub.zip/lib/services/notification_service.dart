import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationService {
  static Future<void> addNotification(String title, String message) async {
    final prefs = await SharedPreferences.getInstance();

    List notifications =
    json.decode(prefs.getString('notifications') ?? '[]');

    notifications.insert(0, {
      'title': title,
      'message': message,
      'date': DateTime.now().toString(),
    });

    await prefs.setString('notifications', json.encode(notifications));
  }

  static Future<List> getNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    return json.decode(prefs.getString('notifications') ?? '[]');
  }
}
