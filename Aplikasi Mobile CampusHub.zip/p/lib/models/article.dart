class Article {
  final String id;
  final String title;
  final String content;
  final String image;
  final String createdAt;

  Article({
    required this.id,
    required this.title,
    required this.content,
    required this.image,
    required this.createdAt,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['id'],
      title: json['title'],
      content: json['content'],
      image: json['image'],
      createdAt: json['created_at'],
    );
  }
}
