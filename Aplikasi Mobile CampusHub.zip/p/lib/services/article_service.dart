import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/article.dart';

class ArticleService {
  static const String baseUrl =
      'http://10.0.2.2/campushub_api/articles';

  // GET LIST
  static Future<List<Article>> getArticles() async {
    final response = await http.get(Uri.parse('$baseUrl/list.php'));
    final jsonData = json.decode(response.body);

    List data = jsonData['data'];
    return data.map((e) => Article.fromJson(e)).toList();
  }

  // DELETE
  static Future<void> deleteArticle(String id) async {
    await http.post(
      Uri.parse('$baseUrl/hapus.php'),
      body: {'id': id},
    );
  }
}
