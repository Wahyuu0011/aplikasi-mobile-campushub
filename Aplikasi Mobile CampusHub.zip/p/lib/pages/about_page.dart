import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xffffffff),
        title: const Text('Tentang Aplikasi'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // HEADER
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: const [
                  Icon(
                    Icons.school,
                    color: Colors.white,
                    size: 50,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'CampusHub',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Aplikasi Informasi Mahasiswa',
                    style: TextStyle(
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // DESKRIPSI
            _buildSection(
              title: 'Deskripsi Aplikasi',
              content:
              'CampusHub adalah aplikasi mobile yang ditujukan untuk mahasiswa sebagai pusat informasi, artikel edukatif, dan data kegiatan kampus. Aplikasi ini membantu mahasiswa mendapatkan informasi dengan lebih mudah dan terstruktur.',
            ),

            _buildSection(
              title: 'Tujuan Aplikasi',
              content:
              'Tujuan utama CampusHub adalah memberikan kemudahan akses informasi bagi mahasiswa, meningkatkan literasi digital, serta mendukung aktivitas akademik dan non-akademik di lingkungan kampus.',
            ),

            _buildSection(
              title: 'Fitur Utama',
              content:
              '1. Login mahasiswa\n'
                  '2. Artikel edukatif untuk mahasiswa\n'
                  '3. Menyimpan artikel ke bookmark\n'
                  '4. Profil mahasiswa\n'
                  '5. Manajemen data berbasis API',
            ),

            _buildSection(
              title: 'Teknologi yang Digunakan',
              content:
              '• Flutter (Mobile Development)\n'
                  '• PHP & MySQL (Backend API)\n'
                  '• Shared Preferences\n'
                  '• REST API\n',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required String content,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[700],
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
