import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'article_detail_page.dart';
import 'article_add_page.dart';
import 'article_edit_page.dart';

class ArticlePage extends StatefulWidget {
  const ArticlePage({super.key});

  @override
  State<ArticlePage> createState() => _ArticlePageState();
}

class _ArticlePageState extends State<ArticlePage> {
  List articles = [];
  bool loading = true;

  final String apiBase = 'http://10.0.2.2/campushub_api/articles';

  @override
  void initState() {
    super.initState();
    getArticles();
  }

  Future<void> getArticles() async {
    setState(() => loading = true);

    final response =
    await http.get(Uri.parse('$apiBase/list.php'));
    final data = json.decode(response.body);

    if (data['status'] == true) {
      setState(() {
        articles = data['data'];
        loading = false;
      });
    } else {
      setState(() => loading = false);
    }
  }

  Future<void> deleteArticle(String id) async {
    await http.post(
      Uri.parse('$apiBase/hapus.php'),
      body: {'id': id},
    );
    getArticles();
  }

  void confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Artikel'),
        content: const Text('Yakin ingin menghapus artikel ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              deleteArticle(id);
            },
            child: const Text(
              'Hapus',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xffffffff),
        title: const Text('Artikel Mahasiswa'),
      ),

      // ===== FLOATING BUTTON TAMBAH =====
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xff2a5298),
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const ArticleAddPage(),
            ),
          );

          if (result == true) getArticles();
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),

      body: loading
          ? const Center(child: CircularProgressIndicator())
          : articles.isEmpty
          ? const Center(
        child: Text(
          'Belum ada artikel',
          style: TextStyle(color: Colors.grey),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: articles.length,
        itemBuilder: (context, index) {
          final item = articles[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color:
                  Colors.black.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                ListTile(
                  title: Text(
                    item['title'],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    item['content'],
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),

                // ===== BACA SELENGKAPNYA =====
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              ArticleDetailPage(
                                  article: item),
                        ),
                      );
                    },
                    child: const Text(
                      'Baca selengkapnya',
                      style: TextStyle(
                        color: Color(0xff2a5298),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 8),
                const Divider(height: 1),

                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  child: Row(
                    mainAxisAlignment:
                    MainAxisAlignment.end,
                    children: [
                      TextButton.icon(
                        icon: const Icon(Icons.edit,
                            size: 18),
                        label: const Text('Edit'),
                        onPressed: () async {
                          final result =
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  ArticleEditPage(
                                      article: item),
                            ),
                          );

                          if (result == true)
                            getArticles();
                        },
                      ),
                      TextButton.icon(
                        icon: const Icon(Icons.delete,
                            size: 18,
                            color: Colors.red),
                        label: const Text(
                          'Hapus',
                          style:
                          TextStyle(color: Colors.red),
                        ),
                        onPressed: () => confirmDelete(
                            item['id'].toString()),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
