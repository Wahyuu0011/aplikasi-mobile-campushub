import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ArticleAddPage extends StatefulWidget {
  const ArticleAddPage({super.key});

  @override
  State<ArticleAddPage> createState() => _ArticleAddPageState();
}

class _ArticleAddPageState extends State<ArticleAddPage> {
  final titleController = TextEditingController();
  final contentController = TextEditingController();
  final imageController = TextEditingController();

  bool loading = false;

  @override
  void dispose() {
    titleController.dispose();
    contentController.dispose();
    imageController.dispose();
    super.dispose();
  }

  Future<void> addArticle() async {
    if (titleController.text.isEmpty ||
        contentController.text.isEmpty ||
        imageController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Semua field wajib diisi')),
      );
      return;
    }

    setState(() => loading = true);

    await http.post(
      Uri.parse('http://10.0.2.2/campushub_api/articles/tambah.php'),
      body: {
        'title': titleController.text,
        'content': contentController.text,
        'image': imageController.text,
      },
    );

    if (!mounted) return;

    setState(() => loading = false);
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F7FA),
      appBar: AppBar(
        backgroundColor: const Color(0xff1E3C72),
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 22,
        ),
        title: const Text('Tambah Artikel'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _field(titleController, 'Judul Artikel'),
            const SizedBox(height: 12),
            _field(contentController, 'Isi Artikel', maxLines: 5),
            const SizedBox(height: 12),
            _field(imageController, 'URL Gambar'),
            const SizedBox(height: 24),

            // ===== BUTTON SIMPAN =====
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                icon: loading
                    ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
                    : const Icon(Icons.save, color: Colors.white),
                label: Text(
                  loading ? 'Menyimpan...' : 'Simpan Artikel',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff1E3C72),
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: loading ? null : addArticle,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {int maxLines = 1}) {
    return TextField(
      controller: c,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
