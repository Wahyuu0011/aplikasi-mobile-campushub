import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'message_page.dart';

class InboxListPage extends StatefulWidget {
  const InboxListPage({super.key});

  @override
  State<InboxListPage> createState() => _InboxListPageState();
}

class _InboxListPageState extends State<InboxListPage> {
  List users = [];
  bool loading = true;

  final String apiUrl =
      'http://10.0.2.2/campushub_api/messages/inbox.php';

  @override
  void initState() {
    super.initState();
    getInbox();
  }

  // ================= GET INBOX =================
  Future<void> getInbox() async {
    try {
      final res = await http.get(Uri.parse(apiUrl));
      final data = json.decode(res.body);

      if (data['status'] == true) {
        setState(() {
          users = data['data'];
          loading = false;
        });
      } else {
        setState(() => loading = false);
      }
    } catch (e) {
      setState(() => loading = false);
    }
  }

  // ================= REFRESH =================
  Future<void> _refreshInbox() async {
    setState(() => loading = true);
    await getInbox();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F7FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Inbox'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: _refreshInbox,
        child: users.isEmpty
            ? ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: const [
            SizedBox(height: 200),
            Center(
              child: Text(
                'Belum ada pesan',
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        )
            : ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];

            return Container(
              margin: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color:
                    Colors.black.withValues(alpha: 0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xffE8EEF8),
                  child: Icon(
                    Icons.person,
                    color: Color(0xff1E3C72),
                  ),
                ),
                title: Text(
                  user['name'] ?? 'User',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  user['last_message'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MessagePage(
                        userId: user['user_id'].toString(),
                      ),
                    ),
                  ).then((_) {
                    _refreshInbox();
                  });
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
