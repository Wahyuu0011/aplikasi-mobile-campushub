package com.example.campushub_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
